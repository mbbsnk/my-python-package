def hello():
    return "Hello from my package!"